# The Witch’s Desk — Production UI Asset Pack

This pack splits the approved ornate UI atlas into individual reusable assets.

## Text rule
- **User-editable text is NOT baked into image assets.** Book titles, chapter/scene names, character/location names, search text, dropdown values, tab titles, manuscript statistics, notes, and other user content must remain live HTML text.
- Fixed application labels may remain baked only where they are not user-editable. This includes the app wordmark, top-level navigation labels, fixed action labels, and fixed inspector/section header labels.
- Blank reusable button/tab/input assets are included whenever text needs to stay live.

## Key folders
- `backgrounds/` exact approved study background
- `branding/` fixed app wordmark
- `nav/` fixed navigation buttons + icon-only transparent versions
- `buttons/` fixed action buttons + blank reusable states/styles
- `controls/` toggles, checks, radios, blank dropdown/search frames
- `tabs/` blank dynamic document tabs
- `toolbar/` individual formatting icons
- `panels/` frames and fixed section headers
- `parchment/` editor surface
- `icons/` manuscript and worldbuilding icons
- `status/` progress/sync/save pieces
- `decor/` dividers, corners, magical desk objects
- `textures/` material/atmosphere tiles
- `manifest.json` source crop and baked-text policy for every file
- `witches-desk-assets.css` starter CSS hooks

The original source atlas is preserved in `reference/` only for visual comparison.
